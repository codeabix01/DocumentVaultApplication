package org.example;

public class DocumentVaultApplication {
    public static void main(String[] args) {
        System.out.println("Document Vault Running...");
    }
}