
# Document Vault — Hackathon Project

## Overview
This project is a secure document storage and retrieval service with user authentication and role-based authorization. Built with Java 17 and Spring Boot 3.x, it features JWT-based security, upload/download endpoints, and in-memory H2 database. Built from scratch without Spring Initializr for maximum learning and customizability.

---

## 🛠️ Steps Taken to Build the Project

### Prompt-Driven Instructions and Steps

#### Prompt 1:
> "I want a Spring Boot application built from scratch — not using Spring Initializr — with login, register, JWT auth, document upload/download, and H2 database."

✅ Created Gradle-based project manually in IntelliJ  
✅ Added necessary Spring Boot plugins and dependencies manually in build.gradle

#### Prompt 2:
> "Add authentication and JWT-based login and registration functionality."

✅ User entity with username, password, role  
✅ JWT token generation and validation  
✅ AuthController for /register and /login endpoints  
✅ Spring Security configured for JWT

#### Prompt 3:
> "Use in-memory H2 database."

✅ H2 dependency and configured application.properties  
✅ H2 console enabled

#### Prompt 4:
> "Add endpoints for uploading and downloading documents."

✅ DocumentController with /upload and /download/{filename} endpoints  
✅ Upload returns filename; download returns file as Resource

#### Prompt 5:
> "Add a full README and project zip."

✅ README.md with tech stack, features, sample payloads, and run instructions  
✅ Zipped full project

#### Prompt 6:
> "Add Swagger and unit/integration tests."

✅ Integrated springdoc-openapi-ui for Swagger  
✅ All endpoints accessible at /swagger-ui.html  
✅ Added JUnit5 and Mockito  
✅ Tests for JwtService, UserService, and AuthController

#### Prompt 7:
> "Add file persistence, role-based access, and logging (SLF4J)."

✅ File Persistence:
- Document entity storing filename, uploadedBy, timestamp
- Files saved to disk
- Metadata persisted using JPA

✅ Role-Based Access Control:
- ADMINs can list all files via /files
- USERs can only view and download their own files
- Roles assigned at registration

✅ Logging:
- SLF4J logging added to services and controllers
- Info-level logs for actions, warn-level logs for access denials

---

## ✅ Enhancements Summary

✅ Swagger/OpenAPI Docs  
✅ Unit and Integration Tests  
✅ Logging via SLF4J  
✅ Persist Uploaded Files  
✅ Role-based Access Control  

🔜 Dockerize the Application (optional)

---

## 📦 Directory Structure

```
DocumentVault/
├── build.gradle
├── README.md
├── src
│   ├── main
│   │   ├── java/org/example
│   │   │   ├── config
│   │   │   ├── controller
│   │   │   ├── dto
│   │   │   ├── entity
│   │   │   ├── repository
│   │   │   ├── service
│   │   │   └── DocumentVaultApplication.java
│   │   └── resources/application.properties
│   └── test/java/org/example
│       ├── service
│       └── controller
```

---

## 🧪 Sample Tests

### JwtServiceTest
```java
@Test
void generateAndValidateToken() {
    String token = jwtService.generateToken("user1");
    assertTrue(jwtService.validateToken(token));
    assertEquals("user1", jwtService.extractUsername(token));
}
```

### UserServiceTest
```java
@Test
void registerUser_shouldReturnJwt() {
    AuthRequest req = new AuthRequest("user1", "pass");
    AuthResponse res = userService.register(req);
    assertNotNull(res.getToken());
}
```

### AuthControllerTest
```java
@Test
void login_shouldReturnToken() throws Exception {
    AuthRequest request = new AuthRequest("user1", "pass");
    mockMvc.perform(post("/login")
        .contentType(MediaType.APPLICATION_JSON)
        .content(asJsonString(request)))
        .andExpect(status().isOk())
        .andExpect(jsonPath("$.token").exists());
}
```
